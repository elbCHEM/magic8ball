

def test_trivial() -> None:
    assert True
    
    
def test_import() -> None:
    import magic8ball as _
